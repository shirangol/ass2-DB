create FUNCTION SimCalculation(mid_1 NUMBER, mid_2 NUMBER, max_distance NUMBER) RETURN
FLOAT IS
    mid_1_year NUMBER;
    mid_2_year NUMBER;
    two_items_distance NUMBER;
    similarity FLOAT;
BEGIN
    SELECT PROD_YEAR INTO mid_1_year FROM MediaItems WHERE MID= mid_1;
    SELECT PROD_YEAR INTO mid_2_year FROM MediaItems WHERE MID= mid_2;    
    two_items_distance:= POWER((mid_1_year-mid_2_year),2);
    similarity:= 1-( two_items_distance/ max_distance);
    RETURN similarity;
END  SimCalculation;
/

