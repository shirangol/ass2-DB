create FUNCTION MaximalDistance RETURN
NUMBER IS
    max_year NUMBER;
    min_year NUMBER;
    max_distance NUMBER;
BEGIN
    SELECT MAX(PROD_YEAR) INTO max_year FROM MediaItems;
    SELECT MIN(PROD_YEAR) INTO min_year FROM MediaItems;
    max_distance:= POWER((max_year-min_year),2);
    RETURN max_distance;
END  MaximalDistance;
/

