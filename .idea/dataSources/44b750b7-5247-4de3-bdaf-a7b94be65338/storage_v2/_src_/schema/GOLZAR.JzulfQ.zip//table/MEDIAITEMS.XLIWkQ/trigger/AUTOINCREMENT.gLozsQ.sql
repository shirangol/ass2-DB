create trigger AUTOINCREMENT
  before insert
  on MEDIAITEMS
  for each row
DECLARE 
    maxIndex NUMBER;
BEGIN
    SELECT MAX(MID) INTO maxIndex FROM MediaItems;
    IF maxIndex IS NULL THEN
        :new.MID:=0;
    ELSE
        :new.MID:= maxIndex+1;
    END IF;
    :new.TITLE_LENGTH:= LENGTH(:new.TITLE);
END;
/

